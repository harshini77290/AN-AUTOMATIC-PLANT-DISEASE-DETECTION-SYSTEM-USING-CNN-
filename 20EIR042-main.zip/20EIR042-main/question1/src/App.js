import Numbers from "./node";

function App() {
  return (
    <Numbers/>
  );
}

export default App;


